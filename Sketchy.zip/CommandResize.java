package Sketchy;

import javafx.geometry.Point2D;
/*
 * One of the many command classes that extend the interface Command that simply contains the two methods of undo and redo.
 * The idea is that there are many commands that want to undo and redo but they all implement those methods in different ways.
 * Thus, command leaves the methods abstract. The key is to store
 * variable in Sketchy class so that you can access information before and after the command is executed.
 * For the command draw pen, undo is accomplished by removing the points added. Redo
 * is accomplished by adding those points back. 
 */
public class CommandResize implements Command{
	private SketchyShape _shape;
	private Point2D _dimensions;
	private double _oldangle;
	private double _xloc;
	private double _yloc;
	
	public CommandResize(SketchyShape shape, Point2D dimensions, double xloc, double yloc,double oldangle
			){
		_shape=shape;
		_dimensions=dimensions;
		_xloc=xloc;
		_yloc=yloc;
		_oldangle= oldangle;
	}
	@Override
	public void undo() {
		_shape.setWidth(_dimensions.getX());
		_shape.setHeight(_dimensions.getY());
		_shape.setX(_xloc);
		_shape.setY(_yloc);
		_shape.getShape().setRotate(_oldangle);
		
	}

	@Override
	public void redo() {
	
		
	}

}
