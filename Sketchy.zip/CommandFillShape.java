package Sketchy;

import javafx.scene.paint.Paint;

/*
 * One of the many command classes that extend the interface Command that simply contains the two methods of undo and redo.
 * The idea is that there are many commands that want to undo and redo but they all implement those methods in different ways.
 * Thus, command leaves the methods abstract. The key is to store
 * variable in Sketchy class so that you can access information before and after the command is executed.
 * For the command draw pen, undo is accomplished by removing the points added. Redo
 * is accomplished by adding those points back. Command fill shape simply keeps track of the old color and in order to undo, it sets the fill of the shape to the old color and redo is to the new color.
 */
public class CommandFillShape implements Command {
	private Paint _oldColor;
	// private Sketchy _sketchy;
	private SketchyShape _sketchyShape;
	private Paint _newColor;

	public CommandFillShape(SketchyShape sketchyShape, Paint oldColor, Paint newColor) {

		_sketchyShape = sketchyShape;
		_oldColor = oldColor;
		_newColor = newColor;

	}

	@Override
	public void undo() {

		_sketchyShape.getShape().setFill(_oldColor);

	}

	@Override
	public void redo() {
		// TODO Auto-generated method stub
		_sketchyShape.getShape().setFill(_newColor);

	}
}
