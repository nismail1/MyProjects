package Sketchy;

import javafx.geometry.Point2D;
/*
								* One of the many command classes that extend the interface Command that simply contains the two methods of undo and redo.
								* The idea is that there are many commands that want to undo and redo but they all implement those methods in different ways.
								* Thus, command leaves the methods abstract. The key is to store
								* variable in Sketchy class so that you can access information before and after the command is executed.
								* For the command draw pen, undo is accomplished by removing the points added. Redo
								* is accomplished by adding those points back. Sets the shape back to its position before translate
								* */

public class CommandTranslate implements Command {
	SketchyShape _selected;
	private Point2D _prev;
	private Point2D _curr;

	public CommandTranslate(SketchyShape selected, Point2D prev, Point2D curr) {
		_prev = prev;
		_curr = curr;
		_selected = selected;
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		if (_selected != null) {
			_selected.setX(_prev.getX());
			_selected.setY(_prev.getY());
		}
	}

	@Override
	public void redo() {
		// TODO Auto-generated method stub
		if (_selected != null) {
			_selected.setX(_curr.getX());
			_selected.setY(_curr.getY());
		}
	}

}
