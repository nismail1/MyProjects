package Sketchy;

import javafx.scene.paint.Paint;

/*
 * One of the many command classes that extend the interface Command that simply contains the two methods of undo and redo.
 * The idea is that there are many commands that want to undo and redo but they all implement those methods in different ways.
 * Thus, command leaves the methods abstract. The key is to store
 * variable in Sketchy class so that you can access information before and after the command is executed.
 * For the command draw pen, undo is accomplished by removing the points added. Redo
 * is accomplished by adding those points back. CommandFillLine undos by having the old color passed in from SKetchy and resetting it to that. Then,
 * redo is by setting it again to the new color passed in.
 */
public class CommandFillLine implements Command {
	CurvedLine _curvedLine;
	Paint _oldColor;
	Paint _newColor;

	public CommandFillLine(CurvedLine curvedLine, Paint oldColor, Paint newColor) {
		_oldColor = oldColor;
		_newColor = newColor;
		_curvedLine = curvedLine;
	}

	@Override
	public void undo() {
	
		_curvedLine.getPolyline().setStroke(_oldColor);
	}

	@Override
	public void redo() {
	
		_curvedLine.getPolyline().setStroke(_newColor);
	}

}
