package Sketchy;

/*
 * One of the many command classes that extend the interface Command that simply contains the two methods of undo and redo.
 * The idea is that there are many commands that want to undo and redo but they all implement those methods in different ways.
 * Thus, command leaves the methods abstract. The key is to store
 * variable in Sketchy class so that you can access information before and after the command is executed.
 * For the command draw pen, undo is accomplished by removing the points added. Redo
 * is accomplished by adding those points back. Undo by raising and redo by lowering
 */
public class CommandLower implements Command {

	private SketchyShape _selected;
	private Sketchy _sketchy;
	private int _shIndex;
	private int _pIndex;
	private Layer _layer;

	public CommandLower(SketchyShape selected, int shIndex, int pIndex, Layer layer, Sketchy sketchy) {

		_selected = selected;
		_shIndex = shIndex;
		_pIndex = pIndex;
		_layer = layer;
		_sketchy = sketchy;
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		if (_selected != null) {

			_layer = new Layer(_shIndex, _pIndex);
			_sketchy.moveShapetoLayer(_selected, _layer);
		}
	}

	@Override
	public void redo() {
		// TODO Auto-generated method stub
		_sketchy.lower();
	}
}
