package Sketchy;

import java.util.ArrayList;
import javafx.scene.layout.Pane;

/*
 * One of the many command classes that extend the interface Command that simply contains the two methods of undo and redo.
 * The idea is that there are many commands that want to undo and redo but they all implement those methods in different ways.
 * Thus, command leaves the methods abstract. The key is to store
 * variable in Sketchy class so that you can access information before and after the command is executed.
 * For the command draw pen, undo is accomplished by removing the points added. Redo
 * is accomplished by adding those points back. COmmand Delete undoes by adding back the shape deleted and it redoes by deleting
 *  the shape just added back.
 */
public class CommandDelete implements Command {
	private SketchyShape _selected;
	private ArrayList<SketchyShape> _shapesArray;
	private Pane _sketchyPane;

	public CommandDelete(SketchyShape selected, ArrayList<SketchyShape> shapesArray, Pane sketchyPane) {
		_selected = selected;
		_sketchyPane = sketchyPane;
		_shapesArray = shapesArray;
	}

	@Override
	public void undo() {

		_sketchyPane.getChildren().add(_selected.getShape());
		_shapesArray.add(_selected);

	}

	@Override
	public void redo() {

		_sketchyPane.getChildren().remove(_selected.getShape());
		_shapesArray.remove(_selected);
	}

}
