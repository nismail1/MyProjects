package Sketchy;


public interface Command{
public void undo();
public void redo();
}
