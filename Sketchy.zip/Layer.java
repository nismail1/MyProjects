package Sketchy;
//This is a bean class that just has setters and getters
public class Layer {
	int _pIndex;
	int _shIndex;
	Sketchy _sketchy;
	public Layer(int pIndex, int shIndex) {
		_pIndex = pIndex;
		_shIndex = shIndex;
	}
	
	public int getShapeIndex() {
		return _shIndex;
	}
	public int getPaneIndex() {
		return _pIndex;
	}

}
