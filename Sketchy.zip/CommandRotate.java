package Sketchy;

/*
 * One of the many command classes that extend the interface Command that simply contains the two methods of undo and redo.
 * The idea is that there are many commands that want to undo and redo but they all implement those methods in different ways.
 * Thus, command leaves the methods abstract. The key is to store
 * variable in Sketchy class so that you can access information before and after the command is executed.
 * For the command draw pen, undo is accomplished by removing the points added. Redo
 * is accomplished by adding those points back. 
 */
public class CommandRotate implements Command {
	private double _oldangle;
	private SketchyShape _shape;
	private double _newangle;

	public CommandRotate(SketchyShape shape, double oldangle, double newangle) {
		_shape = shape;
		_oldangle = oldangle;
		_newangle = newangle;
	}

	@Override
	public void undo() {
		_shape.getShape().setRotate(_oldangle);

	}

	@Override
	public void redo() {
		// TODO Auto-generated method stub
		_shape.getShape().setRotate(_newangle);
	}
}
