package Sketchy;

import cs015.fnl.SketchySupport.FileIO;
//wrapper class for polyline
import javafx.scene.shape.*;

/*
 * Another wrapper class and this one was for the shape polyline. It allowed Sketchy class access to polyline 
 * and saved and loaded any polylines on the screen. It had to extend Saveable in order to save and load
 */
public class CurvedLine implements Saveable {
	Polyline _polyline;

	public CurvedLine() {
		_polyline = new Polyline();

	}

	public Polyline getPolyline() {
		return _polyline;
	}

	public void addPoints(double x, double y) {

		_polyline.getPoints().addAll(x, y);
	}

	@Override
	public void save(FileIO file) {
		file.writeString("Line");
		file.writeInt(_polyline.getPoints().size());
		// using a for each loop in order to access each point in the list
		for (Double d : _polyline.getPoints()) {
			file.writeDouble(d);
		}

	}

	@Override
	public CurvedLine load(FileIO file) {
		int size = file.readInt();
		// looping through the saved list to add each point
		for (int i = 1; i <= size; i++) {
			Double point1 = file.readDouble();
			_polyline.getPoints().add(point1);
		}
		return this;
	}

}
