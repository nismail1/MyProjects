package Sketchy;

import java.util.ArrayList;
import javafx.scene.layout.Pane;

/*
 * One of the many command classes that extend the interface Command that simply contains the two methods of undo and redo.
 * The idea is that there are many commands that want to undo and redo but they all implement those methods in different ways.
 * Thus, command leaves the methods abstract. The key is to store
 * variable in Sketchy class so that you can access information before and after the command is executed.
 * For the command draw pen, undo is accomplished by removing the points added. Redo
 * is accomplished by adding those points back. For command create shape, undo is accomplished by deleting the shape just created 
 * and redo is adding it back logically and graphically.
 */
public class CommandCreateShape implements Command {
	private SketchyShape _sketchyshape;
	private ArrayList<SketchyShape> _shapesArray;
	private Pane _sketchyPane;

	public CommandCreateShape(SketchyShape sketchyshape, ArrayList<SketchyShape> shapesArray, Pane sketchyPane) {
		_sketchyshape = sketchyshape;
		_shapesArray = shapesArray;
		_sketchyPane = sketchyPane;

	}

	@Override
	public void undo() {

		_shapesArray.remove(_sketchyshape);
		_sketchyPane.getChildren().remove(_sketchyshape.getShape());

	}

	@Override
	public void redo() {
		_sketchyPane.getChildren().add(_sketchyshape.getShape());
		_shapesArray.add(_sketchyshape);
	}

}
