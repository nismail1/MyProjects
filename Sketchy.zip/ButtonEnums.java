package Sketchy;
//An enum that helps select between the different buttons so that  you can execute something different in the 
//switch statement of SKetchy
public enum ButtonEnums {FILL,RAISE,LOWER,DELETE,UNDO,REDO,SAVE,LOAD;

}
