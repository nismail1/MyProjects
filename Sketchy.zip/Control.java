package Sketchy;

import javafx.scene.control.Button;


import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
/*
 * THis class handles all the buttons and making sure that they respond to the methods created in SKetchy with all of its game logic.
 * Radiobuttons, regular buttons, and a color picker were all used for the left hand control panel.
 */
public class Control {
	private Sketchy _sketchy;
	private VBox _leftPanel;
	private Color _color;
	private ToggleGroup _group;
	private RadioButton _button1;
	private RadioButton _button2;
	private RadioButton _button3;
	private RadioButton _button4;
	private ColorPicker _colorPicker;
	private Button _button7;
	private Button _button5;
	private Button _button6;
	private Button _button8;
	private Button _button9;
	private Button _button10;
	private Button _button11;
	private Button _button12;
	
	public Control(Sketchy sketchy) {
		_sketchy = sketchy;
		_leftPanel = new VBox();
		_leftPanel.setAlignment(Pos.TOP_CENTER);
		_leftPanel.setSpacing(18);
		_leftPanel.setPrefSize(200, 200);
		_leftPanel.setStyle("-fx-background-color: silver;");
		_group = new ToggleGroup();
		this.setUpDrawing();
		this.setUpColor();
		this.setUpActions();
		this.setUpOperations();
	}

	public void setUpDrawing() {
		Label header1 = new Label("Drawing Options");
		
		_button1 = new RadioButton("Select Shape");
		_button1.setToggleGroup(_group);
		_button1.setOnAction(new RadioButtonHandler());
		_button2 = new RadioButton("Draw with Pen");
		_button2.setToggleGroup(_group);
		_button2.setOnAction(new RadioButtonHandler());
		_button3 = new RadioButton("Draw Rectangle");
		_button3.setToggleGroup(_group);
		_button3.setOnAction(new RadioButtonHandler());
		_button4 = new RadioButton("Draw Ellipse");
		_button4.setToggleGroup(_group);
		_button4.setOnAction(new RadioButtonHandler());
		_leftPanel.getChildren().addAll(header1,_button1,_button2, _button3, _button4);
	}
	public void setUpColor() {
		Label header2 = new Label("Set the Color");
		_colorPicker = new ColorPicker(Color.BLACK);
		_colorPicker.setOnAction(new ColorPickerHandler());
		_leftPanel.getChildren().addAll(header2, _colorPicker);
		
	}
	public void setUpActions() {
		Label header3 = new Label("Shape Actions");
		_button5 = new Button("Raise");
		_button5.setOnAction(new ButtonHandler(ButtonEnums.RAISE));
		_button6 = new Button("Lower");
		_button6.setOnAction(new ButtonHandler(ButtonEnums.LOWER));
		_button7 = new Button("Fill");
		_button7.setOnAction(new ButtonHandler(ButtonEnums.FILL));
		_button8 = new Button("Delete");
		_button8.setOnAction(new ButtonHandler(ButtonEnums.DELETE));
		_leftPanel.getChildren().addAll(header3, _button5, _button6,_button7,_button8);
		
	}
	public void setUpOperations() {
		Label header4 = new Label("Operations");
		_button9 = new Button("Undo");
		_button9.setOnAction(new ButtonHandler(ButtonEnums.UNDO));
		_button10 = new Button("Redo");
		_button10.setOnAction(new ButtonHandler(ButtonEnums.REDO));
		_button11 = new Button("Save");
		_button11.setOnAction(new ButtonHandler(ButtonEnums.SAVE));
		_button12 = new Button("Load");
		_button12.setOnAction(new ButtonHandler(ButtonEnums.LOAD));
		_leftPanel.getChildren().addAll(header4,_button9,_button10,_button11,_button12);
	}
	
	public VBox getVBox() {
		return _leftPanel;
	}
	private class ColorPickerHandler implements EventHandler<ActionEvent> {


		@Override
		public void handle(ActionEvent event) {
			// TODO Auto-generated method stub
	
				_color = _colorPicker.getValue();
				_sketchy.setStrokeLine(_color);
			
		}
	}
	private class ButtonHandler implements EventHandler<ActionEvent>{
		ButtonEnums _commandButton;
		private ButtonHandler(ButtonEnums commandButton) {
			_commandButton = commandButton;
		}
		
		@Override
		public void handle(ActionEvent event) {
			// TODO Auto-generated method stub
			if (_commandButton == ButtonEnums.FILL) {
			_sketchy.setFillShape(_color);
			
			}
			else if(_commandButton == ButtonEnums.RAISE) {
				_sketchy.raise();
			}
			else if(_commandButton == ButtonEnums.LOWER) {
				_sketchy.lower();
			}
			else if(_commandButton == ButtonEnums.DELETE) {
				_sketchy.delete();
			}
			else if(_commandButton == ButtonEnums.UNDO) {
				_sketchy.CommandUndo();
			}
			else if(_commandButton == ButtonEnums.REDO) {
				_sketchy.CommandRedo();
			}
			else if(_commandButton == ButtonEnums.SAVE) {
				_sketchy.save();
			}
			else if(_commandButton == ButtonEnums.LOAD) {
				_sketchy.load();
			}
		}
		
	}
	private class RadioButtonHandler implements EventHandler<ActionEvent>{

		@Override
		public void handle(ActionEvent event) {
			//SketchyEnums _currOption = null;
			if (_button1.isSelected() != false) {
				_sketchy.setOptions(SketchyEnums.SELECTSHAPE);
			}
			else if (_button2.isSelected() != false) {
				
				_sketchy.setOptions(SketchyEnums.DRAWPEN);
				
			}
			else if (_button3.isSelected() != false) {
				_sketchy.setOptions(SketchyEnums.DRAWRECTANGLE);
			}
			
			else if (_button4.isSelected() != false ) {
				_sketchy.setOptions(SketchyEnums.DRAWELLIPSE);
			}
		}
		
	}
}
