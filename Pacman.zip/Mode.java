package Pacman;
public enum Mode{
		FRIGHTENED, SCATTER, CHASE
	}