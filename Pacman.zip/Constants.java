package Pacman;
/*
 * This class defines some constants that you need for the Pacman game.
 */
public class Constants{
	public static final int SQUARE_WIDTH= 30;
	public static final int ROWS= 23;
	public static final int COLS= 23;
}